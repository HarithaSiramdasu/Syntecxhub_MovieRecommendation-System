import { Router, type IRouter } from "express";
import { MOVIES } from "../data/movies.js";
import { recommender } from "../lib/recommender.js";

const router: IRouter = Router();

// GET /movies
router.get("/movies", (req, res) => {
  const {
    search,
    genre,
    minYear,
    maxYear,
    minRating,
    sort = "popularity",
    page = "1",
    limit = "24",
  } = req.query as Record<string, string | undefined>;

  let filtered = [...MOVIES];

  if (search) {
    const q = search.toLowerCase();
    filtered = filtered.filter(
      (m) =>
        m.title.toLowerCase().includes(q) ||
        m.overview.toLowerCase().includes(q) ||
        m.genres.some((g) => g.toLowerCase().includes(q)) ||
        (m.director ?? "").toLowerCase().includes(q) ||
        m.cast.some((c) => c.toLowerCase().includes(q)),
    );
  }

  if (genre) {
    const g = genre.toLowerCase();
    filtered = filtered.filter((m) =>
      m.genres.some((mg) => mg.toLowerCase() === g),
    );
  }

  if (minYear) {
    filtered = filtered.filter((m) => m.year >= Number(minYear));
  }
  if (maxYear) {
    filtered = filtered.filter((m) => m.year <= Number(maxYear));
  }
  if (minRating) {
    filtered = filtered.filter((m) => m.rating >= Number(minRating));
  }

  switch (sort) {
    case "rating":
      filtered.sort((a, b) => b.rating - a.rating);
      break;
    case "year":
      filtered.sort((a, b) => b.year - a.year);
      break;
    case "title":
      filtered.sort((a, b) => a.title.localeCompare(b.title));
      break;
    default:
      filtered.sort((a, b) => b.popularity - a.popularity);
  }

  const pageNum = Math.max(1, Number(page));
  const limitNum = Math.min(48, Math.max(1, Number(limit)));
  const total = filtered.length;
  const totalPages = Math.ceil(total / limitNum);
  const movies = filtered.slice((pageNum - 1) * limitNum, pageNum * limitNum);

  res.json({ movies, total, page: pageNum, limit: limitNum, totalPages });
});

// GET /movies/trending
router.get("/movies/trending", (req, res) => {
  const limit = Math.min(20, Number(req.query["limit"] ?? "10"));
  const trending = [...MOVIES]
    .sort((a, b) => b.popularity - a.popularity)
    .slice(0, limit);
  res.json(trending);
});

// GET /movies/by-genre
router.get("/movies/by-genre", (_req, res) => {
  const genreMap: Record<string, typeof MOVIES> = {};

  for (const movie of MOVIES) {
    for (const genre of movie.genres) {
      if (!genreMap[genre]) genreMap[genre] = [];
      genreMap[genre]!.push(movie);
    }
  }

  const result = Object.entries(genreMap)
    .filter(([, movies]) => movies.length >= 3)
    .sort((a, b) => b[1].length - a[1].length)
    .slice(0, 12)
    .map(([genre, movies]) => ({
      genre,
      movies: movies
        .sort((a, b) => b.rating - a.rating)
        .slice(0, 8),
    }));

  res.json(result);
});

// GET /movies/:id
router.get("/movies/:id", (req, res) => {
  const id = Number(req.params["id"]);
  const movie = MOVIES.find((m) => m.id === id);
  if (!movie) {
    res.status(404).json({ error: "Movie not found" });
    return;
  }
  res.json(movie);
});

// GET /movies/:id/recommendations
router.get("/movies/:id/recommendations", (req, res) => {
  const id = Number(req.params["id"]);
  const movie = MOVIES.find((m) => m.id === id);
  if (!movie) {
    res.status(404).json({ error: "Movie not found" });
    return;
  }
  const recommendations = recommender.recommend(id, 10);
  res.json(recommendations);
});

// GET /genres
router.get("/genres", (_req, res) => {
  const counts: Record<string, number> = {};
  for (const movie of MOVIES) {
    for (const genre of movie.genres) {
      counts[genre] = (counts[genre] ?? 0) + 1;
    }
  }
  const result = Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .map(([genre, count]) => ({ genre, count }));
  res.json(result);
});

// GET /stats
router.get("/stats", (_req, res) => {
  const total = MOVIES.length;
  const avgRating =
    Math.round((MOVIES.reduce((s, m) => s + m.rating, 0) / total) * 10) / 10;
  const moviesWithRuntime = MOVIES.filter((m) => m.runtime !== null);
  const avgRuntime =
    Math.round(
      moviesWithRuntime.reduce((s, m) => s + (m.runtime ?? 0), 0) /
        moviesWithRuntime.length,
    );

  // Genre distribution
  const genreCounts: Record<string, number> = {};
  for (const movie of MOVIES) {
    for (const genre of movie.genres) {
      genreCounts[genre] = (genreCounts[genre] ?? 0) + 1;
    }
  }
  const topGenres = Object.entries(genreCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([genre, count]) => ({ genre, count }));

  // Rating distribution
  const ratingBuckets: Record<string, number> = {
    "7.0–7.4": 0,
    "7.5–7.9": 0,
    "8.0–8.4": 0,
    "8.5–9.0": 0,
  };
  for (const movie of MOVIES) {
    if (movie.rating < 7.5) ratingBuckets["7.0–7.4"]!++;
    else if (movie.rating < 8.0) ratingBuckets["7.5–7.9"]!++;
    else if (movie.rating < 8.5) ratingBuckets["8.0–8.4"]!++;
    else ratingBuckets["8.5–9.0"]!++;
  }
  const ratingDistribution = Object.entries(ratingBuckets).map(
    ([range, count]) => ({ range, count }),
  );

  // Decade distribution
  const decadeCounts: Record<string, number> = {};
  for (const movie of MOVIES) {
    const decade = `${Math.floor(movie.year / 10) * 10}s`;
    decadeCounts[decade] = (decadeCounts[decade] ?? 0) + 1;
  }
  const decadeDistribution = Object.entries(decadeCounts)
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([decade, count]) => ({ decade, count }));

  // Top directors
  const directorMap: Record<string, { count: number; totalRating: number }> =
    {};
  for (const movie of MOVIES) {
    if (!movie.director) continue;
    if (!directorMap[movie.director]) {
      directorMap[movie.director] = { count: 0, totalRating: 0 };
    }
    directorMap[movie.director]!.count++;
    directorMap[movie.director]!.totalRating += movie.rating;
  }
  const topDirectors = Object.entries(directorMap)
    .filter(([, d]) => d.count >= 2)
    .sort((a, b) => b[1].count - a[1].count || b[1].totalRating - a[1].totalRating)
    .slice(0, 8)
    .map(([director, d]) => ({
      director,
      count: d.count,
      avgRating: Math.round((d.totalRating / d.count) * 10) / 10,
    }));

  res.json({
    totalMovies: total,
    avgRating,
    avgRuntime,
    topGenres,
    ratingDistribution,
    decadeDistribution,
    topDirectors,
  });
});

export default router;
