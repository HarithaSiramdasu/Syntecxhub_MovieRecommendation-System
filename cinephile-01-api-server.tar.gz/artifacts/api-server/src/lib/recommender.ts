import { MOVIES, type RawMovie } from "../data/movies.js";

interface TfIdfVector {
  [term: string]: number;
}

function tokenize(text: string): string[] {
  const STOPWORDS = new Set([
    "a", "an", "the", "and", "or", "but", "in", "on", "at", "to", "for",
    "of", "with", "by", "from", "is", "was", "are", "were", "be", "been",
    "being", "have", "has", "had", "do", "does", "did", "will", "would",
    "could", "should", "may", "might", "must", "shall", "can", "need",
    "this", "that", "these", "those", "it", "its", "he", "she", "they",
    "we", "you", "i", "me", "him", "her", "us", "them", "my", "his",
    "their", "our", "your", "who", "what", "which", "when", "where",
    "how", "if", "as", "so", "no", "not", "all", "each", "more", "most",
    "into", "about", "after", "before", "between", "through", "during",
    "while", "than", "then", "now", "also", "just", "only", "very",
    "own", "same", "new", "up", "out", "one", "two", "three", "s",
  ]);

  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((t) => t.length > 2 && !STOPWORDS.has(t));
}

function buildSoup(movie: RawMovie): string {
  const parts: string[] = [
    ...movie.genres.map((g) => g.toLowerCase().replace(/\s+/g, "_")),
    ...movie.keywords.map((k) => k.toLowerCase().replace(/\s+/g, "_")),
    ...movie.cast.slice(0, 3).map((c) => c.toLowerCase().replace(/\s+/g, "_")),
    movie.director ? movie.director.toLowerCase().replace(/\s+/g, "_") : "",
    movie.overview,
    movie.tagline ?? "",
  ];
  return parts.join(" ");
}

function computeTfIdf(documents: string[][]): TfIdfVector[] {
  const N = documents.length;

  // IDF: how rare a term is across all docs
  const docFreq: Record<string, number> = {};
  for (const tokens of documents) {
    const seen = new Set(tokens);
    for (const t of seen) {
      docFreq[t] = (docFreq[t] ?? 0) + 1;
    }
  }

  const idf: Record<string, number> = {};
  for (const [term, df] of Object.entries(docFreq)) {
    idf[term] = Math.log((N + 1) / (df + 1)) + 1; // smooth IDF
  }

  // TF-IDF vector per doc
  return documents.map((tokens) => {
    const tf: Record<string, number> = {};
    for (const t of tokens) {
      tf[t] = (tf[t] ?? 0) + 1;
    }
    const vec: TfIdfVector = {};
    for (const [term, freq] of Object.entries(tf)) {
      vec[term] = (freq / tokens.length) * idf[term]!;
    }
    return vec;
  });
}

function cosineSimilarity(a: TfIdfVector, b: TfIdfVector): number {
  let dot = 0;
  let normA = 0;
  let normB = 0;

  for (const [term, val] of Object.entries(a)) {
    if (b[term] !== undefined) {
      dot += val * b[term]!;
    }
    normA += val * val;
  }
  for (const val of Object.values(b)) {
    normB += val * val;
  }

  if (normA === 0 || normB === 0) return 0;
  return dot / (Math.sqrt(normA) * Math.sqrt(normB));
}

function buildSimilarityReasons(
  queryMovie: RawMovie,
  candidate: RawMovie,
  score: number,
): string[] {
  const reasons: string[] = [];

  const sharedGenres = queryMovie.genres.filter((g) =>
    candidate.genres.includes(g),
  );
  if (sharedGenres.length > 0) {
    reasons.push(`${sharedGenres.join(", ")} film`);
  }

  const sharedKeywords = queryMovie.keywords.filter((k) =>
    candidate.keywords.includes(k),
  );
  if (sharedKeywords.length > 0) {
    reasons.push(...sharedKeywords.slice(0, 2));
  }

  if (
    queryMovie.director &&
    candidate.director &&
    queryMovie.director === candidate.director
  ) {
    reasons.push(`Same director: ${queryMovie.director}`);
  }

  const sharedCast = queryMovie.cast.filter((c) =>
    candidate.cast.includes(c),
  );
  if (sharedCast.length > 0) {
    reasons.push(`Stars ${sharedCast[0]}`);
  }

  const yearDiff = Math.abs(queryMovie.year - candidate.year);
  if (yearDiff <= 5) {
    reasons.push("Same era");
  }

  if (score > 0.5) {
    reasons.push("Highly similar themes");
  } else if (score > 0.3) {
    reasons.push("Similar themes");
  }

  return reasons.slice(0, 4);
}

class RecommenderEngine {
  private vectors: TfIdfVector[] = [];
  private initialized = false;

  initialize(): void {
    if (this.initialized) return;

    const soups = MOVIES.map(buildSoup);
    const tokenized = soups.map(tokenize);
    this.vectors = computeTfIdf(tokenized);
    this.initialized = true;
  }

  recommend(
    movieId: number,
    topN = 10,
  ): Array<{ movie: RawMovie; similarityScore: number; reasons: string[] }> {
    this.initialize();

    const idx = MOVIES.findIndex((m) => m.id === movieId);
    if (idx === -1) return [];

    const queryVec = this.vectors[idx]!;
    const queryMovie = MOVIES[idx]!;

    const scored = MOVIES.map((movie, i) => ({
      movie,
      score: i === idx ? -1 : cosineSimilarity(queryVec, this.vectors[i]!),
    }))
      .filter((x) => x.score >= 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, topN);

    return scored.map(({ movie, score }) => ({
      movie,
      similarityScore: Math.round(score * 1000) / 1000,
      reasons: buildSimilarityReasons(queryMovie, movie, score),
    }));
  }
}

export const recommender = new RecommenderEngine();
